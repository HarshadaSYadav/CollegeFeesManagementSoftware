-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: college_fees_management
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fee_details`
--

DROP TABLE IF EXISTS `fee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_details` (
  `Fee_ID` int(11) NOT NULL AUTO_INCREMENT,
  `STUDENT_ID` int(11) DEFAULT NULL,
  `STUDENT_NAME` varchar(30) DEFAULT NULL,
  `INSTALLMENT_NO` varchar(45) DEFAULT NULL,
  `TOTAL_FEES` varchar(20) DEFAULT NULL,
  `PAID_FEES` varchar(20) DEFAULT NULL,
  `PAY_AMOUNT` varchar(20) DEFAULT NULL,
  `REMAINING_FEES` varchar(20) DEFAULT NULL,
  `MODE_OF_PAYMENT` varchar(40) DEFAULT NULL,
  `EDUCATION_FEES` varchar(40) DEFAULT NULL,
  `DEVELOPMENT_FEES` varchar(40) DEFAULT NULL,
  `STATIONARY_FEES` varchar(40) DEFAULT NULL,
  `UNIVERSITY_FEES` varchar(40) DEFAULT NULL,
  `NACC_FEES` varchar(40) DEFAULT NULL,
  `TC_FEES` varchar(40) DEFAULT NULL,
  `OTHER_FEES` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`Fee_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_details`
--

LOCK TABLES `fee_details` WRITE;
/*!40000 ALTER TABLE `fee_details` DISABLE KEYS */;
INSERT INTO `fee_details` VALUES (1,1,'Harshada Yadav','1','42000','25000.0','25000','17000.0','ONLINE','24900','100','100','100','100','100','100'),(2,3,'Manoj Potdar','1','20000','10600.0','10600','9400.0','CASH','10000','100','100','100','100','100','100'),(3,15,'SSP','1','33000','20000.0','20000','13000.0','CASH','15000','2000','1000','1000','0','0','1000'),(4,2,'Pragati Shinde','1','42000','25000.0','25000','17000.0','CASH','100','100','100','100','0','100','0'),(5,2,'Pragati Shinde','1','42000','20500.0','20500','21500.0','ONLINE','20000','100','100','100','100','0','100');
/*!40000 ALTER TABLE `fee_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_register`
--

DROP TABLE IF EXISTS `student_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_register` (
  `STUDENT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `STUDENT_NAME` varchar(90) DEFAULT NULL,
  `EMAIL_ID` varchar(90) DEFAULT NULL,
  `PHONE_NO` varchar(20) DEFAULT NULL,
  `DEGREE_PROGRAM` varchar(20) DEFAULT NULL,
  `SEMESTER` varchar(60) DEFAULT NULL,
  `GENDER` varchar(20) DEFAULT NULL,
  `ENTRY_YEAR` varchar(60) DEFAULT NULL,
  `CASTE` varchar(20) DEFAULT NULL,
  `TOTAL_FEES` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`STUDENT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_register`
--

LOCK TABLES `student_register` WRITE;
/*!40000 ALTER TABLE `student_register` DISABLE KEYS */;
INSERT INTO `student_register` VALUES (1,'Harshada Yadav','harshadayadavgmail.com','8668823575','B.ED','Sem-I','Female','2023','Open','42000'),(2,'Pragati Shinde','pragatis@gmail.com','5236987410','B.ED','Sem-I','Female','2023','Open','42000'),(3,'Manoj Potdar','manoj03@gmail.com','4865239715','B.ED','Sem-I','Male','2023','OBC','20000'),(4,'Shruti  Adhav','adhavshruti12@gmail.com','8956741236','B.ED','Sem-III','Female','2021','SC','15000'),(5,'Gauri Lolage','gauri364@gmail.com','2563987410','B.ED','Sem-III','Female','2021','OBC','25000'),(6,'Yashraj Ghorpade','raj2003@gmail.com','4589632100','B.ED','Sem-III','Male','2021','Open','42000'),(7,'Sanika Patil','sanikaabasopatil@gmail.com','9860547718','D.ED','Sem-II','Female','2023','Open','45000'),(8,'Omkar Kumbhar','omkarvk@gmail.com','9922775274','D.ED','Sem-II','Male','2023','OBC','27000'),(9,'Pruthviraj Yadav','psyadav14@gmail.com','9922757719','D.ED','Sem-II','Male','2023','OPEN','45000'),(10,'Vitthal Sutar','anish2002@gmail.com','9874561320','D.ED','Sem-IV','Male','2021','OBC','27000'),(11,'Asad Mulla','asadmulla12@gmail.com','9685743210','D.ED','Sem-IV','Male','2021','OBC','27000'),(12,'Abhirav Yadav','ab2003@gmail.com','9785634120','D.ED','Sem-IV','Male','2021','Open','45000'),(13,'','','','null','Sem-IV','null','','',''),(14,'Savita Patil','','','B.ED','Sem-I','Female','2024','Open','33000'),(15,'SSP','','','B.ED','Sem-I','Female','2024','open','33000');
/*!40000 ALTER TABLE `student_register` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-11  9:57:45
