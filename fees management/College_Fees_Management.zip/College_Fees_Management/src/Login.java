import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	protected static final String JOptionpane = null;
	private JPanel contentPane;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Login");
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setBackground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 30));
		lblNewLabel.setBounds(697, 197, 172, 52);
		contentPane.add(lblNewLabel);
		
		username = new JTextField();
		username.setBackground(new Color(255, 255, 255));
		username.setBounds(794, 298, 156, 29);
		contentPane.add(username);
		username.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("UserName:");
		lblNewLabel_1.setFont(new Font("Serif", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(634, 293, 121, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Serif", Font.PLAIN, 22));
		lblNewLabel_2.setBounds(634, 372, 121, 29);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username= username.getText();
				String Password =password.getText();
				
				if(Username.equals("")|| Password.equals("")) {
					JOptionPane.showMessageDialog(null,"Username and Password is required");
				}
				else {
					if(Username.equals("harsha") && Password.equals("1234")) {
					JOptionPane.showMessageDialog(null,"Login Successfull!");
					Home obj = new Home();
					obj.setVisible(true);
					}
					else {
						JOptionPane.showMessageDialog(null,"Login Failed!");
					}
				}
			}
		});
		btnNewButton.setForeground(new Color(248, 248, 255));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton.setBounds(720, 464, 121, 39);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Forgot Password?");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 20));
		lblNewLabel_3.setBounds(693, 525, 164, 29);
		contentPane.add(lblNewLabel_3);
		
		password = new JPasswordField();
		password.setBounds(794, 377, 156, 29);
		contentPane.add(password);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 80);
		contentPane.add(panel);
		
		JLabel lblNewLabel_2_1 = new JLabel("VC");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		panel.add(lblNewLabel_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(138, 10, 1350, 80);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3_1.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3_1);
	}
}
