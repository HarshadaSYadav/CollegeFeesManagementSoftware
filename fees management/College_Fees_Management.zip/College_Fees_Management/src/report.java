import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;

public class report extends JFrame {

	private JPanel contentPane;
	private JTextField fee_id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					report frame = new report();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public report() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton_4 = new JButton("B.ED I  YEAR");
		btnNewButton_4.setBackground(new Color(0, 0, 0));
		btnNewButton_4.setForeground(new Color(255, 255, 255));
		btnNewButton_4.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_4.setBounds(83, 183, 204, 55);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\report_BED1.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }

			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_3 = new JButton("B.ED II YEAR");
		btnNewButton_3.setBackground(new Color(0, 0, 0));
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_3.setBounds(420, 183, 215, 55);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\report_BED2.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }

				
			}
		});
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_2 = new JButton("D.ED I YEAR");
		btnNewButton_2.setBackground(new Color(0, 0, 0));
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_2.setBounds(797, 183, 215, 55);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\report_DED1.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }

			}
		});
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("D.ED II YEAR");
		btnNewButton_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_1.setBounds(1207, 183, 215, 55);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\report_DED2.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }

			}
		});
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("FEES DETAIL");
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton.setBounds(797, 445, 215, 55);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\Feedetails.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }

			}
		});
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_4_1 = new JButton("B.ED I  YEAR ALL");
		btnNewButton_4_1.setBackground(new Color(0, 0, 0));
		btnNewButton_4_1.setForeground(new Color(255, 255, 255));
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\BED1ALL.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
			}
		});
		btnNewButton_4_1.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_4_1.setBounds(83, 264, 204, 55);
		contentPane.add(btnNewButton_4_1);
		
		JButton btnNewButton_3_1 = new JButton("B.ED II YEAR ALL");
		btnNewButton_3_1.setBackground(new Color(0, 0, 0));
		btnNewButton_3_1.setForeground(new Color(255, 255, 255));
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\BED2ALL.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
			}
		});
		btnNewButton_3_1.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_3_1.setBounds(420, 264, 215, 55);
		contentPane.add(btnNewButton_3_1);
		
		JButton btnNewButton_2_1 = new JButton("D.ED I YEAR ALL");
		btnNewButton_2_1.setBackground(new Color(0, 0, 0));
		btnNewButton_2_1.setForeground(new Color(255, 255, 255));
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\DED1ALL.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
			}
		});
		btnNewButton_2_1.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_2_1.setBounds(797, 264, 215, 55);
		contentPane.add(btnNewButton_2_1);
		
		JButton btnNewButton_1_1 = new JButton("D.ED II YEAR ALL");
		btnNewButton_1_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
		           Class.forName("com.mysql.jdbc.Driver");
		           System.out.println("Driver Registered");
		          cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		           System.out.println("Connection Success");
		           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\DED2ALL.jrxml";
		           JasperDesign design = JRXmlLoader.load(path);
		    //JasperReport report = JasperCompileManager.compileReport(design);
		           JasperReport jr=JasperCompileManager.compileReport(design);
		           
		           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
		           JasperViewer jv=new JasperViewer(jp);
		           jv.setVisible(true);
		          // jv.setVisible(true);
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
			}
		});
		btnNewButton_1_1.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton_1_1.setBounds(1207, 264, 215, 55);
		contentPane.add(btnNewButton_1_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 80);
		contentPane.add(panel);
		
		JLabel lblNewLabel_2 = new JLabel("VC");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		panel.add(lblNewLabel_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(138, 10, 1350, 80);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_3 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_5 = new JLabel("Fee ID : ");
		lblNewLabel_5.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_5.setBounds(200, 460, 145, 27);
		contentPane.add(lblNewLabel_5);
		
		fee_id = new JTextField();
		fee_id.setText("0");
		fee_id.setColumns(10);
		fee_id.setBackground(Color.LIGHT_GRAY);
		fee_id.setBounds(326, 463, 188, 27);
		contentPane.add(fee_id);
		
		JButton btnNewButton_1_2 = new JButton("SEARCH");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   String  id = fee_id.getText();   
				
				   Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
			           System.out.println("Connection Success");
			           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\IndiviualReport.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           
			           Map parameters = new HashMap();
			           parameters.put("id", id);
			           
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           jv.setVisible(true);
			            
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
			}
		});
		btnNewButton_1_2.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton_1_2.setBounds(555, 460, 124, 27);
		contentPane.add(btnNewButton_1_2);
	}
}
