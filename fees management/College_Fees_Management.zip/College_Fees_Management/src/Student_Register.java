import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Student_Register extends JFrame {

	private JPanel contentPane;
	private JTextField Student_ID;
	private JTextField Student_Name_1;
	private JTextField Email_ID;
	private JTextField Entry_Year;
	private JTextField Phone_No;
	private JTextField Caste;
	private JTextField Total_Fees;
	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
	String cat1;
	String cat2;
	String degree;
	String gender;
	java.sql.PreparedStatement pst=null;
	
	private void auto_id()
	{
		try
		{
			long id=0;
			
			
			Class.forName("com.mysql.jdbc.Driver");
            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
            st=cn.createStatement();
            String sql ="select * from student_register";
            pst = cn.prepareStatement(sql);
            ResultSet rs=st.executeQuery(sql);
            
            while(rs.next()) {
            	id=Long.parseLong(rs.getString("STUDENT_ID"));
            }
            id++;
            Student_ID.setText(String.valueOf(id));
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.toString());
		}
	}
	private JRadioButton R1;
	private JRadioButton R2;
	private JRadioButton M;
	private JRadioButton F;
	private JComboBox semester;
	
	private void clear_data()
	{
		Student_ID.setText("");
		Student_Name_1.setText("");
		Email_ID.setText("");
		Phone_No.setText("");
		Entry_Year.setText("");
		Caste.setText("");
		Total_Fees.setText("");
		R1.setSelected(false);
		R2.setSelected(false);
		M.setSelected(false);
		F.setSelected(false);
		semester.setSelectedItem(false);
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Register frame = new Student_Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(175, 238, 238));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel STUDENT_ID = new JLabel("Student ID:");
		STUDENT_ID.setFont(new Font("Serif", Font.BOLD, 18));
		STUDENT_ID.setBounds(130, 177, 140, 34);
		contentPane.add(STUDENT_ID);
		
		JLabel EMAIL_ID = new JLabel("Email ID:");
		EMAIL_ID.setFont(new Font("Serif", Font.BOLD, 18));
		EMAIL_ID.setBounds(130, 260, 140, 34);
		contentPane.add(EMAIL_ID);
		
		JLabel Student_Name = new JLabel("Student Name:");
		Student_Name.setFont(new Font("Serif", Font.BOLD, 18));
		Student_Name.setForeground(new Color(0, 0, 0));
		Student_Name.setBounds(965, 172, 140, 34);
		contentPane.add(Student_Name);
		
		JLabel lblNewLabel_4 = new JLabel("Phone No:");
		lblNewLabel_4.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4.setBounds(965, 252, 140, 34);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Gender:");
		lblNewLabel_5.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_5.setBounds(130, 415, 140, 34);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Entry Year:");
		lblNewLabel_6.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_6.setBounds(965, 408, 140, 34);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Semester:");
		lblNewLabel_7.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_7.setBounds(965, 327, 140, 34);
		contentPane.add(lblNewLabel_7);
		
		Student_ID = new JTextField();
		Student_ID.setBackground(new Color(192, 192, 192));
		Student_ID.setForeground(new Color(0, 0, 0));
		Student_ID.setBounds(334, 188, 176, 34);
		contentPane.add(Student_ID);
		Student_ID.setColumns(10);
		
		Student_Name_1 = new JTextField();
		Student_Name_1.setBackground(new Color(211, 211, 211));
		Student_Name_1.setBounds(1196, 178, 176, 34);
		contentPane.add(Student_Name_1);
		Student_Name_1.setColumns(10);
		
		Email_ID = new JTextField();
		Email_ID.setBackground(new Color(211, 211, 211));
		Email_ID.setBounds(334, 264, 176, 34);
		contentPane.add(Email_ID);
		Email_ID.setColumns(10);
		
		Entry_Year = new JTextField();
		Entry_Year.setBackground(new Color(211, 211, 211));
		Entry_Year.setBounds(1196, 414, 176, 34);
		contentPane.add(Entry_Year);
		Entry_Year.setColumns(10);
		
		Phone_No = new JTextField();
		Phone_No.setBackground(new Color(211, 211, 211));
		Phone_No.setBounds(1196, 257, 176, 34);
		contentPane.add(Phone_No);
		Phone_No.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Degree \r\nProgram:");
		lblNewLabel_8.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_8.setBounds(130, 336, 140, 34);
		contentPane.add(lblNewLabel_8);
		
		JButton Add = new JButton("SAVE");
		Add.setForeground(new Color(255, 250, 250));
		Add.setBackground(new Color(0, 0, 0));
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String STUDENT_ID = Student_ID.getText();
					String STUDENT_NAME = Student_Name_1.getText();
					String EMAIL_ID = Email_ID.getText();
					String PHONE_NO = Phone_No.getText();
					//String DEGREE = Degree.getText();
					//String SEMESTER = Semester.getText();
					//String GENDER = Gender.getText();
					String ENTRY_YEAR = Entry_Year.getText();
					String CASTE = Caste.getText();
					String TOTAL_FEES = Total_Fees.getText();
					String SEMESTER =(String)semester.getSelectedItem();
					if(R1.isSelected()) {
						cat1="B.ED";
					}
					if(R2.isSelected()) {
						cat1="D.ED";
					}
					if(M.isSelected()) {
						cat2="Male";
					}
					if(F.isSelected()) {
						cat2="Female";
					}
					String insert = db.Insert("insert into student_register (STUDENT_ID, STUDENT_NAME, EMAIL_ID, PHONE_NO, DEGREE_PROGRAM, SEMESTER, GENDER, ENTRY_YEAR, CASTE, TOTAL_FEES)values('"+STUDENT_ID+"','"+STUDENT_NAME+"','"+EMAIL_ID+"','"+PHONE_NO+"','"+cat1+"','"+SEMESTER
							+"','"+cat2+"','"+ENTRY_YEAR+"','"+CASTE+"','"+TOTAL_FEES+"')");
					JOptionPane.showMessageDialog(null, insert);
					clear_data();
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,ex.toString());
				}
			}
		});
		Add.setFont(new Font("Serif", Font.BOLD, 22));
		Add.setBounds(291, 732, 128, 41);
		contentPane.add(Add);
		
		JButton btnNewButton_1 = new JButton("RESET");
		btnNewButton_1.setForeground(new Color(255, 250, 250));
		btnNewButton_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 clear_data();	
			}
		});
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton_1.setBounds(619, 732, 128, 41);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("BACK");
		btnNewButton_3.setForeground(new Color(255, 250, 250));
		btnNewButton_3.setBackground(new Color(0, 0, 0));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IYEAR obj = new IYEAR();
				obj.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton_3.setBounds(977, 732, 128, 41);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_9 = new JLabel("Caste:");
		lblNewLabel_9.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_9.setBounds(134, 513, 136, 34);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_12 = new JLabel("Total Fees:");
		lblNewLabel_12.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_12.setBounds(965, 505, 140, 34);
		contentPane.add(lblNewLabel_12);
		
		Caste = new JTextField();
		Caste.setBackground(new Color(211, 211, 211));
		Caste.setBounds(334, 517, 176, 34);
		contentPane.add(Caste);
		Caste.setColumns(10);
		
		Total_Fees = new JTextField();
		Total_Fees.setBackground(new Color(211, 211, 211));
		Total_Fees.setBounds(1196, 511, 176, 34);
		contentPane.add(Total_Fees);
		Total_Fees.setColumns(10);
		
		R1 = new JRadioButton("B.ED");
		R1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R1.isSelected()) {
					degree="B.ED";
					R2.setSelected(false);
				}
			}
		});
		R1.setBackground(new Color(211, 211, 211));
		R1.setFont(new Font("Serif", Font.BOLD, 15));
		R1.setBounds(334, 334, 70, 34);
		contentPane.add(R1);
		
		R2 = new JRadioButton("D.ED");
		R2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R2.isSelected()) {
					degree="D.ED";
					R1.setSelected(false);
				}
			}
		});
		R2.setBackground(new Color(211, 211, 211));
		R2.setFont(new Font("Serif", Font.BOLD, 15));
		R2.setBounds(431, 334, 79, 34);
		contentPane.add(R2);
		
		M = new JRadioButton("Male");
		M.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(M.isSelected()) {
					gender="Male";
					F.setSelected(false);
				}
			}
		});
		M.setFont(new Font("Serif", Font.BOLD, 15));
		M.setBackground(new Color(211, 211, 211));
		M.setBounds(334, 420, 70, 34);
		contentPane.add(M);
		
		F = new JRadioButton("Female");
		F.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(F.isSelected()) {
					gender="Female";
					M.setSelected(false);
				}
			}
		});
		F.setFont(new Font("Serif", Font.BOLD, 15));
		F.setBackground(new Color(211, 211, 211));
		F.setBounds(431, 420, 79, 34);
		contentPane.add(F);
		
		semester = new JComboBox();
		semester.setFont(new Font("Serif", Font.BOLD, 13));
		semester.setModel(new DefaultComboBoxModel(new String[] {"Sem-I", "Sem-II", "Sem-III", "Sem-IV"}));
		semester.setBounds(1196, 331, 176, 34);
		contentPane.add(semester);
		
		JButton btnNewButton = new JButton("SEARCH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  try
		          {
					  String id=Student_ID.getText();
					  
		              Class.forName("com.mysql.jdbc.Driver");
		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		              st=cn.createStatement();
		              String sql = "select * from student_register where STUDENT_ID = '"+id+"' ";
		              ResultSet rs=st.executeQuery(sql);
		              while(rs.next())
		              {
		                 // Student_ID.setText(rs.getString("STUDENT_ID"));
		                  Student_Name_1.setText(rs.getString("STUDENT_NAME"));
		                  Email_ID.setText(rs.getString("EMAIL_ID"));
		                  Phone_No.setText(rs.getString("PHONE_NO"));
		                  Entry_Year.setText(rs.getString("ENTRY_YEAR"));
		                  Caste.setText(rs.getString("CASTE"));
		                  Total_Fees.setText(rs.getString("TOTAL_FEES"));
		                  if(rs.getString("DEGREE_PROGRAM").equals("D.ED"))
		                  {
		                	  R2.setSelected(true);
		                  }
		                  else if(rs.getString("DEGREE_PROGRAM").equals("B.ED"))
		                  {
		                	  R1.setSelected(true);
		                  }	                  
		                   
		                  if(rs.getString("GENDER").equals("Male"))
		                  {
		                	  M.setSelected(true);
		                  }
		                  else if(rs.getString("GENDER").equals("Female"))
		                  {
		                	  F.setSelected(true);
		                  }	
		                  
		              }
		          }
				  catch(Exception ex) {
						JOptionPane.showMessageDialog(null,ex.toString());
					}
		        }
			
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton.setBounds(520, 183, 140, 41);
		contentPane.add(btnNewButton);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnHome.setForeground(new Color(255, 250, 250));
		btnHome.setFont(new Font("Serif", Font.BOLD, 22));
		btnHome.setBackground(new Color(0, 0, 0));
		btnHome.setBounds(1352, 100, 128, 41);
		contentPane.add(btnHome);
		
		JButton btnNewButton_2 = new JButton("EDIT FEES DETAILS");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fee_Details obj =new Fee_Details();
				obj.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton_2.setBounds(1255, 637, 225, 41);
		contentPane.add(btnNewButton_2);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 80);
		contentPane.add(panel);
		
		JLabel lblNewLabel_2_1 = new JLabel("VC");
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBounds(147, 10, 1350, 80);
		contentPane.add(panel_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("STUDENT REGISTRATION");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 24));
		lblNewLabel.setBounds(620, 97, 338, 46);
		contentPane.add(lblNewLabel);
		auto_id();
	}
}
