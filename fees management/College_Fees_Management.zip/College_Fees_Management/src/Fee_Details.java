import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Fee_Details extends JFrame {
	private JTextField Total_Fees;
	private JTextField Remaining_Fees;
	private JTextField Paid_Fees;
	private JTextField Student_ID;
	private JTextField Student_Name_1;
	private JTextField Fee_ID;
	private JTextField Installment_No;

	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
java.sql.PreparedStatement pst=null;
private JTextField Pay_Amount;
private JComboBox Modeofpayment;
private JTextField Education_Fee;
private JTextField Stationary_fee;
private JTextField University_fee;
private JTextField Nacc_fee;
private JTextField TC_fee;
private JTextField Other_fee;
private JTextField Development_fee;
	
	private void auto_id()
	{
		try
		{
			long id=0;
			
			
			Class.forName("com.mysql.jdbc.Driver");
            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
            st=cn.createStatement();
            String sql ="select * from fee_details";
            pst = cn.prepareStatement(sql);
            ResultSet rs=st.executeQuery(sql);
            
            while(rs.next()) {
            	id=Long.parseLong(rs.getString("FEE_ID"));
            }
            id++;
            Fee_ID.setText(String.valueOf(id));
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.toString());
		}
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fee_Details frame = new Fee_Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void clear_data()
	{
		Fee_ID.setText("");
		Installment_No.setText("");
		Student_ID.setText("");
		Student_Name_1.setText("");
		Total_Fees.setText("");
		Paid_Fees.setText("");
		Pay_Amount.setText("");
		Remaining_Fees.setText("");
		Education_Fee.setText("");
		University_fee.setText("");
		Development_fee.setText("");
		Stationary_fee.setText("");
		Nacc_fee.setText("");
		TC_fee.setText("");
		Other_fee.setText("");
	}

	/**
	 * Create the frame.
	 */
	public Fee_Details() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TOTAL FEES : ");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel.setBounds(10, 308, 145, 27);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("REMAINING FEES :");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_3.setBounds(1088, 308, 175, 27);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("PAID FEES :");
		lblNewLabel_4.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4.setBounds(354, 308, 153, 27);
		getContentPane().add(lblNewLabel_4);
		
		Total_Fees = new JTextField();
		Total_Fees.setText("0");
		Total_Fees.setBounds(147, 311, 188, 27);
		getContentPane().add(Total_Fees);
		Total_Fees.setColumns(10);
		
		Remaining_Fees = new JTextField();
		Remaining_Fees.setBounds(1267, 311, 188, 27);
		getContentPane().add(Remaining_Fees);
		Remaining_Fees.setColumns(10);
		
		Paid_Fees = new JTextField();
		Paid_Fees.setText("0");
		Paid_Fees.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				double total = Double.parseDouble(Total_Fees.getText());
				double paid = Double.parseDouble(Paid_Fees.getText());
				double pay = Double.parseDouble(Pay_Amount.getText());
				double edu = Double.parseDouble(Education_Fee.getText());
				double uni = Double.parseDouble(University_fee.getText());
				double dev = Double.parseDouble(Development_fee.getText());
				double stat = Double.parseDouble(Stationary_fee.getText());
				double nacc = Double.parseDouble(Nacc_fee.getText());
				double tc = Double.parseDouble(TC_fee.getText());
				double other = Double.parseDouble(Other_fee.getText());
				
				double remaining = total - paid - pay;
				
				Remaining_Fees.setText(String.valueOf(remaining));
			}
		});
		Paid_Fees.setBounds(486, 311, 188, 27);
		getContentPane().add(Paid_Fees);
		Paid_Fees.setColumns(10);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String STUDENT_ID = Student_ID.getText();
					String STUDENT_NAME = Student_Name_1.getText();
					//String FEES_ID = Fee_ID.getText();
				    String INSTALLMENT_NO = Installment_No.getText();
					String TOTAL_FEES = Total_Fees.getText();
					String REMAINING_FEES = Remaining_Fees.getText();
					String PAID_FEES = Paid_Fees.getText();
					String PAY_AMOUNT = Pay_Amount.getText();
					String MODE_OF_PAYMENT = (String)Modeofpayment.getSelectedItem();		
                    String EDUCATION_FEES = Education_Fee.getText();
                    String UNIVERSITY_FEES = University_fee.getText();
                    String DEVELOPMENT_FEES = Development_fee.getText();
                    String STATIONARY_FEES = Stationary_fee.getText();
                    String NACC_FEES = Nacc_fee.getText();
                    String TC_FEES = TC_fee.getText();
                    String OTHER_FEES = Other_fee.getText();
					double fees_paid = Double.parseDouble(PAID_FEES) + Double.parseDouble(PAY_AMOUNT);
					String insert = db.Insert("insert into fee_details (STUDENT_ID, STUDENT_NAME,INSTALLMENT_NO,TOTAL_FEES, REMAINING_FEES, PAID_FEES,PAY_AMOUNT,MODE_OF_PAYMENT,EDUCATION_FEES,UNIVERSITY_FEES,DEVELOPMENT_FEES,STATIONARY_FEES,NACC_FEES,TC_FEES,OTHER_FEES)values('"+STUDENT_ID+"','"+STUDENT_NAME+"','"+INSTALLMENT_NO+"','"+TOTAL_FEES+"','"+REMAINING_FEES+"','"+fees_paid+"','"+PAY_AMOUNT+"','"+MODE_OF_PAYMENT+"','"+EDUCATION_FEES+"','"+UNIVERSITY_FEES+"','"+DEVELOPMENT_FEES+"','"+STATIONARY_FEES+"','"+NACC_FEES+"','"+TC_FEES+"','"+OTHER_FEES+"')");
					JOptionPane.showMessageDialog(null, insert);
					clear_data();
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,ex.toString());
				}
			}
		});
		btnAdd.setForeground(new Color(255, 250, 250));
		btnAdd.setFont(new Font("Serif", Font.BOLD, 22));
		btnAdd.setBackground(new Color(0, 0, 0));
		btnAdd.setBounds(96, 745, 130, 45);
		getContentPane().add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String STUDENT_ID = Student_ID.getText();
					String STUDENT_NAME = Student_Name_1.getText();
					//String FEES_ID = Fee_ID.getText();
					String INSTALLMENT_NO = Installment_No.getText();
					String TOTAL_FEES = Total_Fees.getText();
					String REMAINING_FEES = Remaining_Fees.getText();
					String PAID_FEES = Paid_Fees.getText();
					String PAY_AMOUNT = Pay_Amount.getText();
					String MODE_OF_PAYMENT = (String)Modeofpayment.getSelectedItem();		
					String EDUCATION_FEES = Education_Fee.getText();
                    String UNIVERSITY_FEES = University_fee.getText();
                    String DEVELOPMENT_FEES = Development_fee.getText();
                    String STATIONARY_FEES = Stationary_fee.getText();
                    String NACC_FEES = Nacc_fee.getText();
                    String TC_FEES = TC_fee.getText();
                    String OTHER_FEES = Other_fee.getText();
				
					String update= db.update("update fee_details set STUDENT_ID='"+STUDENT_ID+"',STUDENT_NAME='"+STUDENT_NAME+"',INSTALLMENT_NO='"+INSTALLMENT_NO+"',TOTAL_FEES='"+TOTAL_FEES+"',REMAINING_FEES='"+REMAINING_FEES+"',PAID_FEES='"+PAID_FEES+"',PAY_AMOUNT='"+PAY_AMOUNT+"',MODE_OF_PAYMENT='"+MODE_OF_PAYMENT+"',EDUCATION_FEES='"+EDUCATION_FEES+"',UNIVERSITY_FEES='"+UNIVERSITY_FEES+"',DEVELOPMENT_FEES='"+DEVELOPMENT_FEES+"',STATIONARY_FEES='"+STATIONARY_FEES+"',NACC_FEES='"+NACC_FEES+"',TC_FEES='"+TC_FEES+"',OTHER_FEES='"+OTHER_FEES+"' where STUDENT_ID='"+STUDENT_ID+"'");

					JOptionPane.showMessageDialog(null, update);
					clear_data();
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,ex.toString());
			}
			}
		});
		btnUpdate.setForeground(new Color(255, 250, 250));
		btnUpdate.setFont(new Font("Serif", Font.BOLD, 22));
		btnUpdate.setBackground(new Color(0, 0, 0));
		btnUpdate.setBounds(382, 745, 130, 45);
		getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

				{

				String fee_id = Fee_ID.getText();

				String delete=db.delete("delete from fee_details where FEE_ID='"+fee_id+"' ");

				JOptionPane.showMessageDialog(null, delete);
				clear_data();

				}

				catch(Exception ex) {

				JOptionPane.showMessageDialog(null, ex.toString());

				}
			}
		});
		btnDelete.setForeground(new Color(255, 250, 250));
		btnDelete.setFont(new Font("Serif", Font.BOLD, 22));
		btnDelete.setBackground(new Color(0, 0, 0));
		btnDelete.setBounds(660, 745, 130, 45);
		getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setForeground(new Color(255, 250, 250));
		btnBack.setFont(new Font("Serif", Font.BOLD, 22));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Info obj = new Student_Info();
				obj.setVisible(true);
			}
		});
		btnBack.setBackground(new Color(0, 0, 0));
		btnBack.setBounds(940, 745, 130, 45);
		getContentPane().add(btnBack);
		
		JLabel STUDENT_ID = new JLabel("Student ID:");
		STUDENT_ID.setFont(new Font("Serif", Font.BOLD, 18));
		STUDENT_ID.setBounds(570, 138, 145, 34);
		getContentPane().add(STUDENT_ID);
		
		Student_ID = new JTextField();
		Student_ID.setColumns(10);
		Student_ID.setBackground(new Color(211, 211, 211));
		Student_ID.setBounds(740, 145, 188, 27);
		getContentPane().add(Student_ID);
		
		JButton btnNewButton = new JButton("SEARCH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
		          {
					  String id=Student_ID.getText();
					  String name=Student_Name_1.getText();
					  
					  
		              Class.forName("com.mysql.jdbc.Driver");
		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		              st=cn.createStatement();
		              String sql = "select * from student_register where STUDENT_ID = '"+id+"' || STUDENT_NAME = '"+name+"' ";
		              ResultSet rs=st.executeQuery(sql);
		              if(rs.next())
		              { 
		            	  Student_ID.setText(rs.getString("STUDENT_ID"));
		                  Student_Name_1.setText(rs.getString("STUDENT_NAME")); 
		                  Total_Fees.setText(rs.getString("TOTAL_FEES"));
		                  Paid_Fees.setText(rs.getString("PAID_FEES"));
		              }
		              
		              rs.close();
		              
		               
		              sql = "select * from fee_details where STUDENT_ID = '"+id+"' || STUDENT_NAME = '"+name+"' ";
		              rs=st.executeQuery(sql);
		              if(rs.next())
		              { 
		                  Paid_Fees.setText(rs.getString("PAID_FEES")); 
		              }
		              
		          }
				  catch(Exception ex) {
						JOptionPane.showMessageDialog(null,ex.toString());
					}
			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton.setBounds(953, 142, 124, 27);
		getContentPane().add(btnNewButton);
		
		JLabel Student_Name = new JLabel("Student Name:");
		Student_Name.setForeground(Color.BLACK);
		Student_Name.setFont(new Font("Serif", Font.BOLD, 18));
		Student_Name.setBounds(10, 182, 153, 27);
		getContentPane().add(Student_Name);
		
		Student_Name_1 = new JTextField();
		Student_Name_1.setForeground(new Color(0, 0, 0));
		Student_Name_1.setColumns(10);
		Student_Name_1.setBackground(new Color(211, 211, 211));
		Student_Name_1.setBounds(144, 185, 188, 27);
		getContentPane().add(Student_Name_1);
		
		JLabel lblNewLabel_5 = new JLabel("Fee ID : ");
		lblNewLabel_5.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_5.setBounds(10, 142, 145, 27);
		getContentPane().add(lblNewLabel_5);
		
		Fee_ID = new JTextField();
		Fee_ID.setBackground(new Color(192, 192, 192));
		Fee_ID.setBounds(144, 145, 188, 27);
		getContentPane().add(Fee_ID);
		Fee_ID.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Installment No. :");
		lblNewLabel_6.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_6.setBounds(10, 223, 153, 27);
		getContentPane().add(lblNewLabel_6);
		
		Installment_No = new JTextField();
		Installment_No.setBackground(new Color(192, 192, 192));
		Installment_No.setBounds(144, 226, 188, 27);
		getContentPane().add(Installment_No);
		Installment_No.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("SEARCH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
		          {
					  String id=Fee_ID.getText();
					  
					  
		              Class.forName("com.mysql.jdbc.Driver");
		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		              st=cn.createStatement();
		              String sql = "select * from fee_details where Fee_ID = '"+id+"' ";
		              ResultSet rs=st.executeQuery(sql);
		              while(rs.next())
		              {
		                 Student_ID.setText(rs.getString("STUDENT_ID"));
		                  Student_Name_1.setText(rs.getString("STUDENT_NAME"));
		                  Installment_No.setText(rs.getString("INSTALLMENT_NO"));
		                  //Fee_ID.setText(rs.getString("FEE_ID"));
		                  Total_Fees.setText(rs.getString("TOTAL_FEES"));
		                  Remaining_Fees.setText(rs.getString("REMAINING_FEES"));
		                  Paid_Fees.setText(rs.getString("PAID_FEES"));
		                  Pay_Amount.setText(rs.getString("PAY_AMOUNT"));
		              }
		          }
				  catch(Exception ex) {
						JOptionPane.showMessageDialog(null,ex.toString());
					}
			}
		});
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton_1.setBounds(354, 142, 124, 27);
		getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_7 = new JLabel("PAY AMOUNT :");
		lblNewLabel_7.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_7.setBounds(717, 308, 145, 27);
		getContentPane().add(lblNewLabel_7);
		
		Pay_Amount = new JTextField();
		Pay_Amount.setText("0");
		Pay_Amount.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				double total = Double.parseDouble(Total_Fees.getText());
				double paid = Double.parseDouble(Paid_Fees.getText());
				double pay = Double.parseDouble(Pay_Amount.getText());
				double remaining = total - paid - pay;
				
				Remaining_Fees.setText(String.valueOf(remaining));
			}
		});
		Pay_Amount.setColumns(10);
		Pay_Amount.setBounds(860, 311, 188, 27);
		getContentPane().add(Pay_Amount);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnHome.setForeground(new Color(255, 250, 250));
		btnHome.setFont(new Font("Serif", Font.BOLD, 22));
		btnHome.setBackground(new Color(0, 0, 0));
		btnHome.setBounds(1364, 76, 130, 45);
		getContentPane().add(btnHome);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 61);
		getContentPane().add(panel);
		
		JLabel lblNewLabel_2 = new JLabel("VC");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(144, 10, 1350, 61);
		getContentPane().add(panel_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3_1.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3_1);
		
		JLabel STUDENT_ID_1 = new JLabel("Mode of Payment :");
		STUDENT_ID_1.setFont(new Font("Serif", Font.BOLD, 18));
		STUDENT_ID_1.setBounds(570, 178, 155, 34);
		getContentPane().add(STUDENT_ID_1);
		
		Modeofpayment = new JComboBox();
		Modeofpayment.setFont(new Font("Serif", Font.BOLD, 15));
		Modeofpayment.setModel(new DefaultComboBoxModel(new String[] {"ONLINE", "CASH", "CHECK", "SCOLARSHIP"}));
		Modeofpayment.setBounds(740, 183, 188, 27);
		getContentPane().add(Modeofpayment);
		
		JLabel lblNewLabel_4_1 = new JLabel("University Fee : ");
		lblNewLabel_4_1.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_1.setBounds(61, 436, 153, 27);
		getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("NACC  Fee: ");
		lblNewLabel_4_2.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_2.setBounds(61, 491, 153, 27);
		getContentPane().add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_3 = new JLabel("T.C. Fee :");
		lblNewLabel_4_3.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_3.setBounds(61, 547, 153, 27);
		getContentPane().add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_4_4 = new JLabel("Education Fee : ");
		lblNewLabel_4_4.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_4.setBounds(61, 380, 153, 27);
		getContentPane().add(lblNewLabel_4_4);
		
		JLabel lblNewLabel_4_5 = new JLabel("Stationary Fee : ");
		lblNewLabel_4_5.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_5.setBounds(595, 380, 153, 27);
		getContentPane().add(lblNewLabel_4_5);
		
		JLabel lblNewLabel_4_6 = new JLabel("Other Fee : ");
		lblNewLabel_4_6.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_6.setBounds(61, 656, 153, 27);
		getContentPane().add(lblNewLabel_4_6);
		
		JLabel lblNewLabel_4_7 = new JLabel("Development Fee : ");
		lblNewLabel_4_7.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4_7.setBounds(59, 604, 155, 27);
		getContentPane().add(lblNewLabel_4_7);
		
		Education_Fee = new JTextField();
		Education_Fee.setText("0");
		Education_Fee.setColumns(10);
		Education_Fee.setBounds(257, 383, 188, 27);
		getContentPane().add(Education_Fee);
		
		Stationary_fee = new JTextField();
		Stationary_fee.setText("0");
		Stationary_fee.setColumns(10);
		Stationary_fee.setBounds(782, 383, 188, 27);
		getContentPane().add(Stationary_fee);
		
		University_fee = new JTextField();
		University_fee.setText("0");
		University_fee.setColumns(10);
		University_fee.setBounds(257, 439, 188, 27);
		getContentPane().add(University_fee);
		
		Nacc_fee = new JTextField();
		Nacc_fee.setText("0");
		Nacc_fee.setColumns(10);
		Nacc_fee.setBounds(257, 494, 188, 27);
		getContentPane().add(Nacc_fee);
		
		TC_fee = new JTextField();
		TC_fee.setText("0");
		TC_fee.setColumns(10);
		TC_fee.setBounds(257, 547, 188, 27);
		getContentPane().add(TC_fee);
		
		Other_fee = new JTextField();
		Other_fee.setText("0");
		Other_fee.setColumns(10);
		Other_fee.setBounds(257, 659, 188, 27);
		getContentPane().add(Other_fee);
		
		Development_fee = new JTextField();
		Development_fee.setText("0");
		Development_fee.setColumns(10);
		Development_fee.setBounds(257, 604, 188, 27);
		getContentPane().add(Development_fee);
		
		JButton Print = new JButton("PRINT");
		Print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = Fee_ID.getText();
			
				Connection cn=null;
			    
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
			           System.out.println("Connection Success");
			           String path="C:\\Users\\harsh\\eclipse-workspace\\College_Fees_Management\\src\\IndiviualReport.jrxml";
			           JasperDesign design = JRXmlLoader.load(path); 
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           Map parameters = new HashMap();
			           parameters.put("id", id);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           jv.setVisible(true); 
		           }catch(Exception ex)
		           {
		           System.out.println(ex);
		           }
				
				
				
				
			}
		});
		Print.setForeground(new Color(255, 250, 250));
		Print.setFont(new Font("Serif", Font.BOLD, 22));
		Print.setBackground(Color.BLACK);
		Print.setBounds(1218, 745, 130, 45);
		getContentPane().add(Print);
		
		auto_id();
	}
}
