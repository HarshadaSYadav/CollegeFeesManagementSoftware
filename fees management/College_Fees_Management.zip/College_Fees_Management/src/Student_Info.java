import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.DefaultComboBoxModel;

public class Student_Info extends JFrame {

	private JPanel contentPane;
	private JTextField Student_Name_1;
	private JTextField Caste;
	private JTextField Email_ID;
	private JTextField Student_ID;
	private JTextField Phone_No;
	private JTextField Entry_Year;
	private JTextField Degree;

	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
	String cat1="";
	String cat2="";
	String degree;
	String gender;
	private JComboBox semester;
	private JComboBox semester_1;
	private JRadioButton R1;
	private JRadioButton R2;
	private JRadioButton M;
	private JRadioButton F;
	
java.sql.PreparedStatement pst=null;
	
	private void auto_id()
	{
		try
		{
			long id=0;
			
			
			Class.forName("com.mysql.jdbc.Driver");
            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
            st=cn.createStatement();
            String sql ="select * from student_register";
            pst = cn.prepareStatement(sql);
            ResultSet rs=st.executeQuery(sql);
            
            while(rs.next()) {
            	id=Long.parseLong(rs.getString("STUDENT_ID"));
            }
            id++;
            Student_ID.setText(String.valueOf(id));
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.toString());
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Info frame = new Student_Info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Info() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel STUDENT_ID = new JLabel("Student ID:");
		STUDENT_ID.setFont(new Font("Serif", Font.BOLD, 18));
		STUDENT_ID.setBounds(34, 240, 104, 26);
		contentPane.add(STUDENT_ID);
		
		Student_Name_1 = new JTextField();
		Student_Name_1.setForeground(new Color(0, 0, 0));
		Student_Name_1.setColumns(10);
		Student_Name_1.setBackground(new Color(211, 211, 211));
		Student_Name_1.setBounds(205, 315, 176, 26);
		contentPane.add(Student_Name_1);
		
		JLabel Student_Name = new JLabel("Student Name:");
		Student_Name.setForeground(Color.BLACK);
		Student_Name.setFont(new Font("Serif", Font.BOLD, 18));
		Student_Name.setBounds(34, 310, 122, 30);
		contentPane.add(Student_Name);
		
		Caste = new JTextField();
		Caste.setColumns(10);
		Caste.setBackground(new Color(211, 211, 211));
		Caste.setBounds(1180, 454, 183, 31);
		contentPane.add(Caste);
		
		Email_ID = new JTextField();
		Email_ID.setColumns(10);
		Email_ID.setBackground(new Color(211, 211, 211));
		Email_ID.setBounds(1180, 315, 183, 28);
		contentPane.add(Email_ID);
		
		Student_ID = new JTextField();
		Student_ID.setColumns(10);
		Student_ID.setBackground(new Color(211, 211, 211));
		Student_ID.setBounds(205, 247, 104, 27);
		contentPane.add(Student_ID);
		
		Phone_No = new JTextField();
		Phone_No.setColumns(10);
		Phone_No.setBackground(new Color(211, 211, 211));
		Phone_No.setBounds(1180, 240, 183, 34);
		contentPane.add(Phone_No);
		
		JLabel EMAIL_ID = new JLabel("Email ID:");
		EMAIL_ID.setFont(new Font("Serif", Font.BOLD, 18));
		EMAIL_ID.setBounds(961, 308, 96, 26);
		contentPane.add(EMAIL_ID);
		
		JLabel lblNewLabel_4 = new JLabel("Phone No:");
		lblNewLabel_4.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4.setBounds(961, 237, 96, 26);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_8 = new JLabel("Degree \r\nProgram:");
		lblNewLabel_8.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_8.setBounds(34, 375, 141, 28);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_7 = new JLabel("Semester:");
		lblNewLabel_7.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_7.setBounds(961, 372, 96, 34);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_5 = new JLabel("Gender:");
		lblNewLabel_5.setFont(new Font("Serif", Font.BOLD, 15));
		lblNewLabel_5.setBounds(141, 464, 60, -45);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Entry Year:");
		lblNewLabel_6.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_6.setBounds(34, 534, 104, 34);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_9 = new JLabel("Caste:");
		lblNewLabel_9.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_9.setBounds(961, 451, 96, 34);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_5_1 = new JLabel("Gender:");
		lblNewLabel_5_1.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_5_1.setBounds(34, 453, 80, 26);
		contentPane.add(lblNewLabel_5_1);
		
		Entry_Year = new JTextField();
		Entry_Year.setColumns(10);
		Entry_Year.setBackground(new Color(211, 211, 211));
		Entry_Year.setBounds(205, 541, 183, 28);
		contentPane.add(Entry_Year);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					if(R1.isSelected())
					{
						cat1="B.ED";
					}
					if(R2.isSelected())
					{
						cat1="D.ED";
					}
					if(M.isSelected())
					{
						cat2="Male";
						}
					if(F.isSelected())
					{
						cat2="Female";
					}
					String STUDENT_ID = Student_ID.getText();
					String NAME = Student_Name_1.getText();
					String EMAIL_ID = Email_ID.getText();
					String PHONE_NO = Phone_No.getText(); 
					String SEMESTER = semester_1.getSelectedItem().toString(); 
					String ENTRY_YEAR = Entry_Year.getText();
					String CASTE = Caste.getText();
					 
			
					String update= db.update("update student_register set STUDENT_ID='"+STUDENT_ID+"',STUDENT_NAME='"+NAME+"',EMAIL_ID='"+EMAIL_ID+"',PHONE_NO='"+PHONE_NO+"',DEGREE_PROGRAM='"+cat1+"',SEMESTER='"+SEMESTER+"',GENDER='"+cat2+"',ENTRY_YEAR='"+ENTRY_YEAR+"',CASTE='"+CASTE+"' where STUDENT_ID='"+STUDENT_ID+"' ");

					JOptionPane.showMessageDialog(null, update);
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,ex.toString());
			}
			}
		});
		btnUpdate.setForeground(new Color(255, 250, 250));
		btnUpdate.setFont(new Font("Serif", Font.BOLD, 22));
		btnUpdate.setBackground(new Color(0, 0, 139));
		btnUpdate.setBounds(396, 735, 132, 43);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

				{

				String stud_id = Student_ID.getText();

				String delete=db.delete("delete from student_register where STUDENT_ID='"+stud_id+"' ");

				JOptionPane.showMessageDialog(null, delete);

				}

				catch(Exception ex) {

				JOptionPane.showMessageDialog(null, ex.toString());

				}
			}
		});
		btnDelete.setForeground(new Color(255, 250, 250));
		btnDelete.setFont(new Font("Serif", Font.BOLD, 22));
		btnDelete.setBackground(new Color(0, 0, 139));
		btnDelete.setBounds(678, 735, 132, 43);
		contentPane.add(btnDelete);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setForeground(new Color(255, 250, 250));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IYEAR obj = new IYEAR();
				obj.setVisible(true);
			}
		});
		btnBack.setFont(new Font("Serif", Font.BOLD, 22));
		btnBack.setBackground(new Color(0, 0, 139));
		btnBack.setBounds(939, 735, 132, 43);
		contentPane.add(btnBack);
		
		JButton btnNewButton = new JButton("EDIT FEES DETAILS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fee_Details obj =new Fee_Details();
				obj.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 20));
		btnNewButton.setBounds(1116, 612, 247, 43);
		contentPane.add(btnNewButton);
		
		R1 = new JRadioButton("B.ED");
		R1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R1.isSelected()) {
					degree="B.ED";
					R2.setSelected(false);
				}
			}
		});
		R1.setFont(new Font("Serif", Font.BOLD, 15));
		R1.setBackground(new Color(211, 211, 211));
		R1.setBounds(205, 379, 64, 31);
		contentPane.add(R1);
		
		R2 = new JRadioButton("D.ED");
		R2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R2.isSelected()) {
					degree="D.ED";
					R1.setSelected(false);
				}
			}
		});
		R2.setFont(new Font("Serif", Font.BOLD, 15));
		R2.setBackground(new Color(211, 211, 211));
		R2.setBounds(306, 377, 71, 34);
		contentPane.add(R2);
		
		semester_1 = new JComboBox();
		semester_1.setFont(new Font("Serif", Font.BOLD, 13));
		semester_1.setModel(new DefaultComboBoxModel(new String[] {"Sem-I", "Sem-II", "Sem-III", "Sem-IV"}));
		semester_1.setBounds(1180, 376, 183, 30);
		contentPane.add(semester_1);
		
		M = new JRadioButton("Male");
		M.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(M.isSelected()) {
					gender="Male";
					F.setSelected(false);
				}
			}
		});
		M.setFont(new Font("Serif", Font.BOLD, 15));
		M.setBackground(new Color(211, 211, 211));
		M.setBounds(205, 452, 80, 33);
		contentPane.add(M);
		
		F = new JRadioButton("Female");
		F.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(F.isSelected()) {
					gender="Female";
					M.setSelected(false);
				}
			}
		});
		F.setFont(new Font("Serif", Font.BOLD, 15));
		F.setBackground(new Color(211, 211, 211));
		F.setBounds(306, 454, 85, 31);
		contentPane.add(F);
		
		JButton btnNewButton_1 = new JButton("SEARCH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
		          {
					  String id=Student_ID.getText();
					  
		              Class.forName("com.mysql.jdbc.Driver");
		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		              st=cn.createStatement();
		              String sql = "select * from student_register where STUDENT_ID = '"+id+"' ";
		              ResultSet rs=st.executeQuery(sql);
		              while(rs.next())
		              {
		                 //Student_ID.setText(rs.getString("STUDENT_ID"));
		                  Student_Name_1.setText(rs.getString("STUDENT_NAME"));
		                  Email_ID.setText(rs.getString("EMAIL_ID"));
		                  Phone_No.setText(rs.getString("PHONE_NO"));
		                  Entry_Year.setText(rs.getString("ENTRY_YEAR"));
		                  Caste.setText(rs.getString("CASTE"));
		                  
		                  
		                  if(rs.getString("DEGREE_PROGRAM").equals("D.ED"))
		                  {
		                	  R2.setSelected(true);
		                  }
		                  else if(rs.getString("DEGREE_PROGRAM").equals("B.ED"))
		                  {
		                	  R1.setSelected(true);
		                  }	                  
		                   
		                  if(rs.getString("GENDER").equals("Male"))
		                  {
		                	  M.setSelected(true);
		                  }
		                  else if(rs.getString("GENDER").equals("Female"))
		                  {
		                	  F.setSelected(true);
		                  }	
		                 
		              }
		          }
				  catch(Exception ex) {
						JOptionPane.showMessageDialog(null,ex.toString());
					}
			}
		});
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 18));
		btnNewButton_1.setBounds(326, 249, 112, 26);
		contentPane.add(btnNewButton_1);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnHome.setForeground(new Color(255, 250, 250));
		btnHome.setFont(new Font("Serif", Font.BOLD, 22));
		btnHome.setBackground(new Color(0, 0, 205));
		btnHome.setBounds(1360, 96, 112, 43);
		contentPane.add(btnHome);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 80);
		contentPane.add(panel);
		
		JLabel lblNewLabel_2 = new JLabel("VC");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		panel.add(lblNewLabel_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(141, 10, 1350, 80);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_3 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("STUDENT INFO");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 24));
		lblNewLabel.setBounds(597, 133, 193, 52);
		contentPane.add(lblNewLabel);
		
		auto_id();
	}
}
