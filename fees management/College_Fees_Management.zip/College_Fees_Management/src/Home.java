import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JEditorPane;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class Home extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JPanel panel;
	private JPanel panel_1;
	private JRadioButton R1;
	private JRadioButton R2;
	
	String degree;
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		/*ImageIcon img = new ImageIcon(this.getClass().getResource("home.jpg"));
		lblNewLabel.setIcon(img);*/
		
		table = new JTable();
		table.setBounds(113, 350, 145, -142);
		contentPane.add(table);
		
		panel = new JPanel();
		panel.setBounds(24, 21, 118, 80);
		contentPane.add(panel);
		
		lblNewLabel_2 = new JLabel("VC");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		panel_1 = new JPanel();
		panel_1.setBounds(180, 21, 1350, 80);
		contentPane.add(panel_1);
		
		lblNewLabel_3 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3);
		
		R1 = new JRadioButton("B.ED");
		R1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R1.isSelected()) {
					degree="B.ED";
					R2.setSelected(false);
				}
			}
		});
		R1.setFont(new Font("Serif", Font.BOLD, 28));
		R1.setBounds(531, 279, 111, 68);
		contentPane.add(R1);
		
		R2 = new JRadioButton("D.ED");
		R2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R2.isSelected()) {
					degree="D.ED";
					R1.setSelected(false);
				}
			}
		});
		R2.setFont(new Font("Serif", Font.BOLD, 28));
		R2.setBounds(903, 279, 104, 68);
		contentPane.add(R2);
		
		JButton btnNewButton = new JButton("Ist YEAR");
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R1.isSelected()) {
					IYEAR obj =new IYEAR();
					obj.setVisible(true);
					R2.setSelected(false);
				}
				else {
					IDED obj =new IDED();
					obj.setVisible(true);
					R1.setSelected(false);
				}
			}
		});
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 28));
		btnNewButton.setBounds(478, 395, 232, 68);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("IInd YEAR");
		btnNewButton_1.setForeground(new Color(255, 250, 250));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(R1.isSelected()) {
					IIYEAR obj =new IIYEAR();
					obj.setVisible(true);
					R2.setSelected(false);
				}
				else {
					IIDED obj =new IIDED();
					obj.setVisible(true);
					R1.setSelected(false);
				}
			}
		});
		btnNewButton_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 28));
		btnNewButton_1.setBounds(853, 395, 232, 66);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Add Student");
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setBackground(new Color(0, 0, 0));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Register obj =new Student_Register();
				obj.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Serif", Font.BOLD, 28));
		btnNewButton_2.setBounds(1248, 120, 262, 58);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("FEE DETAILS");
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fees_Table obj =new Fees_Table();
				obj.setVisible(true);
			}
		});
		btnNewButton_3.setBackground(new Color(0, 0, 0));
		btnNewButton_3.setFont(new Font("Serif", Font.BOLD, 28));
		btnNewButton_3.setBounds(653, 532, 254, 68);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel(" ");
		lblNewLabel.setBounds(0, 0, 1540, 803);
		contentPane.add(lblNewLabel);
		ImageIcon img = new ImageIcon(this.getClass().getResource("home1.jpg"));
		lblNewLabel.setIcon(img);
		
		
	
	}
}
