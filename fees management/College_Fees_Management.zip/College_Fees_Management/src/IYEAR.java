import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.JTextComponent;

import com.mysql.jdbc.PreparedStatement;
import java.io.*;
import net.proteanit.sql.DbUtils;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class IYEAR extends JFrame {

	private JPanel contentPane;
	private JTextField Student_ID;
	private JTable table;
	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
	java.sql.PreparedStatement pst=null;
	private JComboBox year_box;
	protected JTextComponent Student_Name_1;

	
	
	
	
	private void table_data()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
            st=cn.createStatement();
            String sql ="select * from student_register where DEGREE_PROGRAM='B.ED' && (SEMESTER = 'Sem-I' || SEMESTER = 'Sem-II') ";
            pst = cn.prepareStatement(sql);
            ResultSet rs=st.executeQuery(sql);
            table.setModel(DbUtils.resultSetToTableModel(rs));
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.toString());
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IYEAR frame = new IYEAR();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IYEAR() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1580, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(175, 238, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Student_ID = new JTextField();
		Student_ID.setBounds(38, 111, 306, 27);
		contentPane.add(Student_ID);
		Student_ID.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("BACK");
		btnNewButton_3.setForeground(new Color(255, 250, 250));
		btnNewButton_3.setBackground(new Color(0, 0, 0));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton_3.setBounds(1369, 733, 118, 44);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Register obj =new Student_Register();
				obj.setVisible(true);

				table_data();
			}
		});
		
		
		btnNewButton.setForeground(new Color(255, 250, 250));
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setBounds(1225, 221, 118, 44);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{ 
					Class.forName("com.mysql.jdbc.Driver");
		            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");
		            st=cn.createStatement();
		            String sql ="select * from student_register where DEGREE_PROGRAM='B.ED' && (STUDENT_ID='"+Student_ID.getText()+"' || ENTRY_YEAR = '"+year_box.getSelectedItem()+"') && (SEMESTER = 'Sem-I' || SEMESTER = 'Sem-II')||(STUDENT_NAME LIKE '"+Student_ID.getText()+"%') ";
		            pst = cn.prepareStatement(sql);
		            ResultSet rs=st.executeQuery(sql);
		            table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null,ex.toString());
				}
				
		        }
			
		});
		
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 22));
		btnNewButton_1.setBounds(501, 104, 137, 34);
		contentPane.add(btnNewButton_1);
		
		year_box = new JComboBox();
		year_box.setFont(new Font("Serif", Font.BOLD, 22));
		year_box.setModel(new DefaultComboBoxModel(new String[] {"Select Year", "2020", "2021", "2022", "2023", "2024"}));
		year_box.setBounds(354, 104, 137, 34);
		contentPane.add(year_box);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnHome.setForeground(new Color(255, 250, 250));
		btnHome.setFont(new Font("Serif", Font.BOLD, 22));
		btnHome.setBackground(new Color(0, 0, 0));
		btnHome.setBounds(1369, 105, 118, 44);
		contentPane.add(btnHome);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Info obj =new Student_Info();
				obj.setVisible(true);
			}
		});
		btnUpdate.setForeground(new Color(255, 250, 250));
		btnUpdate.setFont(new Font("Serif", Font.BOLD, 22));
		btnUpdate.setBackground(new Color(0, 0, 0));
		btnUpdate.setBounds(1369, 221, 118, 44);
		contentPane.add(btnUpdate);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 118, 80);
		contentPane.add(panel);
		
		JLabel lblNewLabel_2 = new JLabel("VC");
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 45));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(145, 10, 1350, 80);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_3 = new JLabel("VASANT COLLEGE OF EDUCATION");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 44));
		panel_1.add(lblNewLabel_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 285, 1449, 426);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"New column", "New column", "New column"
			}
		));
		
		table_data();
	}
}
